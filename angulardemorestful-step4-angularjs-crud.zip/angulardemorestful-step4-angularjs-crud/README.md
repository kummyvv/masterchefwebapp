angulardemorestful
==================

This is a sample project for some of my blog posts at [http://draptik.github.io](http://draptik.github.io).

## Git instructions for specific blog posts

- [http://draptik.github.io/blog/2013/07/13/angularjs-example-using-a-java-restful-web-service/](http://draptik.github.io/blog/2013/07/13/angularjs-example-using-a-java-restful-web-service/)

``` sh
git clone git@github.com:draptik/angulardemorestful.git
cd angulardemorestful
git checkout -f step1
```

- [http://draptik.github.io/blog/2013/07/18/guice-in-java-web-application/](http://draptik.github.io/blog/2013/07/18/guice-in-java-web-application/)

``` sh
git clone git@github.com:draptik/angulardemorestful.git
cd angulardemorestful
git checkout -f step2-guice
```

- [http://draptik.github.io/blog/2013/07/19-unit-testing-restful-services/](http://draptik.github.io/blog/2013/07/19-unit-testing-restful-services/)

``` sh
git clone git@github.com:draptik/angulardemorestful.git
cd angulardemorestful
git checkout -f step3-backend-test
```
