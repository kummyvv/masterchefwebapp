package ngdemo.service.contract;

import ngdemo.domain.User;

public interface DummyService {
    User getDefaultUser();
}
