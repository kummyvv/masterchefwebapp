﻿(function () {
    'use strict';

    var recipesService = angular.module('recipesService', ['ngResource']);

    recipesService.factory('Recipe', ['$resource', function ($resource) {
        return $resource('/api/recipes/:id');
    }]);

})();