﻿(function () {
    'use strict';

    angular.module('masterChefApp', [
        // Angular modules 
        //'ngRoute'

        // Custom modules 
        'recipesService'
        // 3rd Party Modules
        
    ]);
})();