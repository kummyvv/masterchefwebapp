﻿(function () {
    'use strict';

    angular
        .module('masterChefApp')
        .controller('recipesController', recipesController);
     

    recipesController.$inject = ['$scope', 'Recipe'];

    function recipesController($scope, Recipe) {
        $scope.recipes = Recipe.query();
    }
  
})();

