﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(RDLCReport.Startup))]
namespace RDLCReport
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
