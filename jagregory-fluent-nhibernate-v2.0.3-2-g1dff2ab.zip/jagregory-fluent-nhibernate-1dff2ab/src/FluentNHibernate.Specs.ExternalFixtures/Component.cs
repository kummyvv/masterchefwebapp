﻿namespace FluentNHibernate.Specs.ExternalFixtures
{
    public class Component {}
}