﻿namespace FluentNHibernate.Specs.PersistenceModel.Fixtures
{
    class UnionChildEntity : UnionEntity
    {}
}