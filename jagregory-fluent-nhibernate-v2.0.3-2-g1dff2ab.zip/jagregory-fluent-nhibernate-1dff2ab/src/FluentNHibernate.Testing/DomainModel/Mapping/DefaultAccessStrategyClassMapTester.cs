using FluentNHibernate.Mapping;
using NUnit.Framework;

namespace FluentNHibernate.Testing.DomainModel.Mapping
{
    [TestFixture]
    public class DefaultAccessStrategyClassMapTester
    {
        [Test]
        public void AccessAsProperty_SetsAccessStrategyToProperty()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.Property())
                .RootElement.HasAttribute("default-access", "property");
        }

        [Test]
        public void AccessAsField_SetsAccessStrategyToField()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.Field())
                .RootElement.HasAttribute("default-access", "field");
        }

        [Test]
        public void AccessAsCamelCaseField_SetsAccessStrategyToField_and_SetsNamingStrategyToCamelCase()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.CamelCaseField())
                .RootElement.HasAttribute("default-access", "field.camelcase");
        }

        [Test]
        public void AccessAsCamelCaseFieldWithUnderscorePrefix_SetsAccessStrategyToField_and_SetsNamingStrategyToCamelCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.CamelCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "field.camelcase-underscore");
        }

        [Test]
        public void AccessAsLowerCaseField_SetsAccessStrategyToField_and_SetsNamingStrategyToLowerCase()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.LowerCaseField())
                .RootElement.HasAttribute("default-access", "field.lowercase");
        }

        [Test]
        public void AccessAsLowerCaseFieldWithUnderscorePrefix_SetsAccessStrategyToField_and_SetsNamingStrategyToLowerCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.LowerCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "field.lowercase-underscore");
        }

        [Test]
        public void AccessAsPascalCaseFieldWithUnderscorePrefix_SetsAccessStrategyToField_and_SetsNamingStrategyToPascalCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.PascalCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "field.pascalcase-underscore");
        }

        [Test]
        public void AccessAsPascalCaseFieldWithMPrefix_SetsAccessStrategyToField_and_SetsNamingStrategyToLowerCaseM()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.PascalCaseField(Prefix.m))
                .RootElement.HasAttribute("default-access", "field.pascalcase-m");
        }

        [Test]
        public void AccessAsPascalCaseFieldWithMUnderscorePrefix_SetsAccessStrategyToField_and_SetsNamingStrategyToLowerCaseMUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.PascalCaseField(Prefix.mUnderscore))
                .RootElement.HasAttribute("default-access", "field.pascalcase-m-underscore");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughCamelCaseField_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToCamelCase()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughCamelCaseField())
                .RootElement.HasAttribute("default-access", "nosetter.camelcase");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughCamelCaseFieldWithUnderscorePrefix_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToCamelCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughCamelCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "nosetter.camelcase-underscore");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughLowerCaseField_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToLowerCase()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughLowerCaseField())
                .RootElement.HasAttribute("default-access", "nosetter.lowercase");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughLowerCaseFieldWithUnderscorePrefix_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToLowerCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughLowerCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "nosetter.lowercase-underscore");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughPascalCaseFieldWithUnderscorePrefix_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToPascalCaseUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughPascalCaseField(Prefix.Underscore))
                .RootElement.HasAttribute("default-access", "nosetter.pascalcase-underscore");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughPascalCaseFieldWithMPrefix_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToPascalCaseM()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughPascalCaseField(Prefix.m))
                .RootElement.HasAttribute("default-access", "nosetter.pascalcase-m");
        }

        [Test]
        public void AccessAsReadOnlyPropertyThroughPascalCaseFieldWithMUnderscorePrefix_SetsAccessStrategyToNoSetter_and_SetsNamingStrategyToPascalCaseMUnderscore()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnlyPropertyThroughPascalCaseField(Prefix.mUnderscore))
                .RootElement.HasAttribute("default-access", "nosetter.pascalcase-m-underscore");
        }

        [Test]
        public void AccessAsReadOnlySetsAccessStrategyToReadOnly()
        {
            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.ReadOnly())
                .RootElement.HasAttribute("default-access", "readonly");
        }

        [Test]
        public void AccessUsingClassName_SetsAccessAttributeToClassName()
        {
            string className = typeof(FakePropertyAccessor).AssemblyQualifiedName;

            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.Using(className))
                .RootElement.HasAttribute("default-access", className);
        }

        [Test]
        public void AccessUsingClassType_SetsAccessAttributeToAssemblyQualifiedName()
        {
            var className = typeof(FakePropertyAccessor).AssemblyQualifiedName;

            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.Using(typeof(FakePropertyAccessor)))
                .RootElement.HasAttribute("default-access", className);
        }

        [Test]
        public void AccessUsingClassGenericParameter_SetsAccessAttributeToAssemblyQualifiedName()
        {
            var className = typeof(FakePropertyAccessor).AssemblyQualifiedName;

            new MappingTester<PropertyTarget>()
                .ForMapping(c => c.HibernateMapping.DefaultAccess.Using<FakePropertyAccessor>())
                .RootElement.HasAttribute("default-access", className);
        }
    }
}